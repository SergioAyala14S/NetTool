#!/bin/sh

java -jar ./nettool.jar
